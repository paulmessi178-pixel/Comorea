# COMOREA

Plateforme de formations en ligne — Informatique, Bureautique, Robotique, Programmation, Design et Animation — avec suivi de progression et gamification.

## 🚀 Lancer le site

Le site est une page unique autonome, sans backend ni installation.

- **En local** : ouvre `index.html` dans un navigateur (Chrome, Edge, Firefox...).
- **En ligne (GitHub Pages)** : Settings → Pages → Source: `main` / `root`, puis ouvre l'URL fournie par GitHub.

## ✨ Fonctionnalités

- Authentification locale (compte, connexion)
- 6 formations avec modules et exercices interactifs
- Système de progression : XP, niveaux, badges, streak quotidien
- Certificats de réussite téléchargeables en PDF
- Thème clair / sombre, sons, raccourcis clavier
- **Sauvegarde / restauration de progression** (export-import JSON)
- **Minuteur d'étude Pomodoro** (25 min focus / 5 min pause)
- **Notes personnelles** par formation
- **Partage rapide** de sa progression
- **Statistiques automatiques** : formation favorite, jours actifs, moyenne d'exercices par jour actif, meilleure journée, graphique d'activité hebdomadaire

## 🗂️ Structure

```
COMOREA/
├── index.html   # page complète du site (HTML + CSS + JS)
└── README.md
```

## 💾 Données

Toute la progression est stockée localement dans le navigateur (`localStorage`). Utilise le bouton **Exporter ma progression** dans le profil pour en garder une copie ou la transférer sur un autre appareil.

## 📧 Contact

paul178paul@gmail.com
